# Escopo Funcional

https://docs.google.com/spreadsheets/d/143zpSglVv-5L89tLnSFPqRM-nnDKwOpnVzyTcuXSAz4/edit?usp=sharing
