# Estimativas

Cronograma Funcionários

https://docs.google.com/spreadsheets/d/1MnlLcBGVFBwUYXBwKn8yiIwfpqh0zJW8V5hFfE-C_30/edit?usp=sharing

Custo Funcionários

https://docs.google.com/spreadsheets/d/1mxbKi7yp6FqS4cSlSZPnsDJW9Z3B4cqIBG-uizob6PQ/edit?usp=sharing